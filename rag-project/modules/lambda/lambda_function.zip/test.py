import boto3
import json


client = boto3.client(service_name='bedrock-runtime', region_name='us-east-1')
model_id = 'us.amazon.nova-micro-v1:0'
messages = [
    {'role': 'user', 'content': [{'text': 'Write a short poem'}]},
]
body = json.dumps({
    'messages': messages,
})

try:
    response = client.invoke_model(
        modelId=model_id,
        body=body,
    )
    response_body = json.loads(response['body'].read())
    content_text = response_body['output']['message']['content'][0]['text']
    print(content_text)
except Exception as e:
    print(f"Error: {e}")